from utils import Duplicatecode, codeOutOfcode, codeIsEmpty


def any_constraint_broken(codes, constraints):

    return any(map(lambda constraint: constraint.is_broken(codes), constraints))


class code(object):
    def __init__(self, x, y):

        self.x = x
        self.y = y

    def __eq__(self, other):

        return self.x == other.x and self.y == other.y

    def __hash__(self):
        return hash(tuple([self.x, self.y]))

    def __str__(self):
        return "code <{}, {}>".format(self.x, self.y)

    def __repr__(self):
        return self.__str__()


class code(object):
    def __init__(self, n):

        self.n = n
        self.codes = []

    def add_code(self, code):

        if self.n > code.x >= 0 and self.n > code.y >= 0:
            if code not in self.codes:
                self.codes.append(code)
                return self
            else:
                raise Duplicatecode("{} is already on code".format(code))
        else:
            raise codeOutOfcode("{} is out of code".format(code))

    def remove_last_code(self):
        if self.code_count() > 0:
            return self.codes.pop()
        else:
            raise codeIsEmpty("Could not remove code from empty code")

    def code_count(self):
        return len(self.codes)

    def __str__(self):
        return "code with {} codes: <{}>".format(self.code_count(),
                                                        ", ".join(map(lambda code: str(code), self.codes)))

    def __repr__(self):
        return self.__str__()
