from datetime import datetime
from model import any_constraint_broken
from stats import Stat
from utils import log, seconds_since


def csp(N, constraints, new_value_selector_function, timeout=10):


    def go(existing_codes):

        if seconds_since(start_time) > timeout:
            log("TIMEOUT! Could not find solution in {} seconds.".format(timeout))
            return None
        if any_constraint_broken(existing_codes, constraints):
            return None
        stats.append(Stat(len(stats), seconds_since(start_time), len(existing_codes)))
        if len(existing_codes) >= N:
            log("Found solution! Returning : {}".format(existing_codes))
            return existing_codes
        possible_values = new_value_selector_function(existing_codes, N)
        if N - len(existing_codes) > len(possible_values):
                                                                           len(possible_values)))
            return None
        else:

            for possible_code in possible_values:
                codes = go(existing_codes + [possible_code])
                if codes is not None:
                    return codes
            return None

    stats = []
    start_time = datetime.now()
    log("Initializing with {} as new value generator".format(new_value_selector_function.func_name))
    return go(existing_codes=[]), stats
